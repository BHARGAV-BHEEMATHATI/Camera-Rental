package newcam;

import java.util.Scanner;
// main class
public class cameraRental
{
	    public static void main(String[] args)//main method
	    {
	        CameraOperations cameraOperations = new CameraOperations();   //creating object for class cameraOperations
	        userinfo user = new userinfo();     //creating object for class userinfo
	        user.setwalletamount(200);    //initializing the wallet amount
	     
	        System.out.println("+-------------------------------+");
	        System.out.println("| WELCOME TO CAMERA RENTAL APP  |");
	        System.out.println("+-------------------------------+");
	        System.out.println("PLEASE LOGIN TO CONTINUE-");
	        Scanner scanner = new Scanner(System.in);
	        System.out.print("ENTER USERNAME : ");     
	        String username = scanner.nextLine();    //taking username as input
	        System.out.print("ENTER PASSWORD : ");
	        String password = scanner.nextLine();    //taking password  as input
	        
	        if (authenticateUser(username, password)) 
	        {
	            System.out.println("LOGIN SUCCESSFUL. WELCOME, " + username + "!");
	            user.setusername(username);
	            
	            
	            Camera cam1=new Camera();     //initializing the some camera details for the  
	 	       cam1.brand="canon";
	 	       cam1.model="dslr200";
	 	       cam1.rentperday=200;	   
	 	       cameraOperations.addCamera(cam1);

	 	       
	 	       Camera cam2=new Camera();
	 	       cam2.brand="nixon";
	 	       cam2.model="dslr200";
	 	       cam2.rentperday=500;
	 	       cameraOperations.addCamera(cam2);

	 	       
	 	       Camera cam3=new Camera();
	 	       cam3.brand="nixon";
	 	       cam3.model="dsl8000";
	 	       cam3.rentperday=250;
	 	      cameraOperations.addCamera(cam3);

	 	       
	 	     Camera cam4=new Camera();
	 	       cam4.brand="sonym";
	 	       cam4.model="dslr80";
	 	       cam4.rentperday=2500;
	 	      cameraOperations.addCamera(cam4);
	 	      
	 	      
	 	     Camera cam5=new Camera();
	 	       cam5.brand="canon";
	 	       cam5.model="dsl8000";
	 	       cam5.rentperday=150;
	 	      cameraOperations.addCamera(cam5);
	 	      
	 	     Camera cam6=new Camera();
	 	       cam6.brand="canox";
	 	       cam6.model="ds20500";
	 	       cam6.rentperday=350;
	 	      cameraOperations.addCamera(cam6);
	        
	        int choice;

	        do {
	            System.out.println("\n MENU:");
	            System.out.println("1. MY CAMERA");
	            System.out.println("2. RENT A CAMERA");
	            System.out.println("3. VIEW ALL CAMERAS");
	            System.out.println("4. MY WALLET");
	            System.out.println("5. EXIT");
	            System.out.print("ENTER YOUR CHOICE: ");
	            choice = scanner.nextInt();

	            switch (choice) {                                       //switch case for the main menu
	                case 1:
	                    handleMyCamera(cameraOperations);
	                    
	                    break;
	                case 2:
	                    String rentResult = cameraOperations.rentCamera(choice, user);
	                    System.out.println(rentResult);
	                    break;
	                case 3:
	                    cameraOperations.listCameras();
	                    break;
	                case 4:
	                    user.AddAmountToWallet();
	                    System.out.println("WALLET BALANCE UPDATED."+"CURRENT BALANCE - INR."+user.getwalletamount());
	                    break;
	                case 5:
	                    System.out.println("EXITING THE PROGRAM. GOODBYE!");
	                    scanner.close();
	                    break;
	                default:
	                    System.out.println("INVALID CHOICE.PLEASE ENTER A VALID OPTION.");
	            }
	        } while (choice != 5);
	    }
	        else {
	        	System.out.println("USER NOT FOUND");
	        }
	    }
	        
	    private static boolean authenticateUser(String enteredUsername, String enteredPassword) {
	    	 String username = "b";
	         String password = "p";
	         return enteredUsername.equals(username) && enteredPassword.equals(password);
		}

		private static void handleMyCamera(CameraOperations cameraOperations) {
	        Scanner scanner = new Scanner(System.in);
	        int myCameraChoice;

	        do {
	        	  System.out.println("\n MY CAMERA MENU:");
	              System.out.println("1. ADD CAMERA");
	              System.out.println("2. REMOVE CAMERA");
	              System.out.println("3. VIEW MY CAMERAS");
	              System.out.println("4. GO TO PREVIOUS MENU");
	              System.out.print("ENTER YOUR CHOICE: ");
	            myCameraChoice = scanner.nextInt();

	            switch (myCameraChoice) {
	                case 1:
	                    handleAddCamera(cameraOperations);
                         cameraOperations.listCameras();
	                    break;
	                case 2:
	                	cameraOperations.listCameras();
	              	   System.out.print("ENTER CAMERA ID TO REMOVE: ");
	                	   int camId = scanner.nextInt();
	                	   String removeResult = cameraOperations.removeCamera(camId);
	                       System.out.println(removeResult);
		                	cameraOperations.listCameras();

	                    break;
	                case 3:
	                	
	                    cameraOperations.viewMyCameras();
	                    break;
	                case 4:
	                    System.out.println("GOING TO THE PREVIOUS MENU.");
	                    break;
	                default:
	                    System.out.println("INVALID CHOICE.PLEASE ENTER A VALID OPTION.");
	            }
	        } while (myCameraChoice != 4);
	    }

	    private static void handleAddCamera(CameraOperations cameraOperations) {             //method to add a new camera details
	       
	    	Scanner scanner = new Scanner(System.in);
	    	Camera newCamera = new Camera();     
	        System.out.print("ENTER BRAND: ");
	        newCamera.brand = scanner.next();
	        System.out.print("ENTER MODEL: ");
	        newCamera.model = scanner.next();
	        System.out.print("ENTER RENT PER DAY: ");
	        newCamera.rentperday = scanner.nextFloat();

	        String addResult = cameraOperations.addCamera(newCamera);
	        System.out.println(addResult);
	    }
	}