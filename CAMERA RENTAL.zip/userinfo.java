package newcam;

import java.util.Scanner;

// setting user info
public class userinfo 
	{
	    private String username;
	    private String password;
	    private double walletamount;

	   //setters for userinfo 
	    public void setusername(String username) {
	        this.username = username;
	    }

	    public void setpassword(String password) {
	        this.password = password;
	    }

	    public void setwalletamount(double walletamount) {
	        this.walletamount = walletamount;
	    }
	    
	    //getters for userinfo

	    public String getusername() {
	        return username;
	    }

	    public String getpassword() {
	        return password;
	    }

	    public double getwalletamount() {
	        return walletamount;
	    }
	    
	    
	  //method for adding amount to the wallet
	    public void AddAmountToWallet()
	    {
	        Scanner scanner = new Scanner(System.in);//scanner to take the amount to be added as input
	        double currentbalance, newbalance;
	        
	        currentbalance = walletamount;
	        
	        System.out.println("\nCURRENT BALANCE:" + " " + currentbalance);//printing the current balance
	        System.out.println("DO YOU WANT TO DEPOSIT MORE AMOUNT TO YOUR WALLET");
	        System.out.println("1.YES"+"\n2.NO");
	        String choiceToAdd=scanner.next();//This scanner is used to get the user whether need to add money to wallet or not 
	        
	        
	        if("1".equals(choiceToAdd)) //this checks the input with the string "1" 
	        {
	        System.out.println("\n ENTER AMOUNT TO BE ADD TO THE WALLET:");
	        double amountToAdd = scanner.nextDouble();//this takes the input of amount which is need to add to the wallet
	        newbalance = currentbalance + amountToAdd;
	       setwalletamount(newbalance);// In this the wallet balance is updated with the new balance
	      

	    }
	        else
	        {
	        	System.out.println("NO AMOUNT ADDED. CURRENT BALANCE REMAINS:"+" "+currentbalance);//This step performs when the user not opted to add money to the wallet
	        }
	        	
	    }
	    
	}