package newcam;

//this class performs camera details setup

public class Camera
{
	
	
    	private static int initialCamId=0;
	    int camid;
	    String brand;
	    String model;
	    float rentperday;
	    String status;
	    String rentedBy;
	    
	    public Camera()
	    {
	    	this.camid=++initialCamId;
	    }

	    public void setStatus(String status)
	    {
	        this.status = status;
	    }

	    public String getstatus()
	    {
	        return status;
	    }

	    public void setRentedBy(String rentedBy) 
	    {
	        this.rentedBy = rentedBy;
	    }

	    public String getRentedBy() 
	    {
	        return rentedBy;
	    
			
		}
	}