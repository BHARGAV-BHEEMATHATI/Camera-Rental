package newcam;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

// This performs all the operations 
public class CameraOperations {

	    private List<Camera> rentACamera = new ArrayList<>();//creating the list named rentACamera
	    
	    
        // this  used to add a new camera
	    public String addCamera(Camera camera)
	    {
	    	 for (Camera existingCamera : rentACamera) 
	    	 {
	    	        if (existingCamera.camid == camera.camid)//checking with the camid entered with the existing camid
	    	        {
	    	            return "CAMERA ID ALREADY EXISTS. PLEASE CHOOSE A UNIQUE ID.";
	    	        }
	    	    }
	            camera.setStatus("Available");
	            rentACamera.add(camera);//camera is added to the list
	            return "YOUR CAMERA HAS BEEN SUCCESSFULLY ADDED TO THE LIST.";
	            
	        }
	  
	    
	    
	    
        
	    public String removeCamera(int camId) {
	    	
	        for (Camera camera : rentACamera) {
	            if (camera.camid == camId) {
	                rentACamera.remove(camera);
	                return "CAMERA SUCCESSFULLY REMOVED FROM THE LIST.";
	                
	            }
	        }
	        return "CAMERA NOT FOUND.";
	    }


	    //method for listing the all cameras
	    public void listCameras()
	    {
	        if (rentACamera.isEmpty())//checking the list is empty or not
	        {
	            System.out.println("NO CAMERAS AVAILABLE.");
	        } 
	        
	        else
	        {
	        	
	        	 System.out.println("LIST OF AVAILABLE CAMERAS:");
	             System.out.println("================================================================================");
	             System.out.println("CAMERA ID" + "       " + "BRAND" + "        " + "MODEL" + "         " + "RENT PER DAY" + "      " + "STATUS");
	             System.out.println("================================================================================");
	             for (Camera camera : rentACamera) {
	                 System.out.println(camera.camid + "               " + camera.brand + "        " + camera.model + "            " + camera.rentperday + "             " + camera.status + "\n");
	             }
	        }
            System.out.println("================================================================================");

	    } 

	      
	    
	    public void viewMyCameras() 
	    {
	        listCameras();
	    }

	        

	    public String rentCamera(int camId, userinfo user)
	    {
	    	
	    	listCameras();//listing all the available cameras
	    	Scanner sc=new Scanner(System.in);
	    	System.out.println("ENTER CAMERA ID YOU WANT TO RENT:");
	    	camId=sc.nextInt();  //taking input which camera need to take rent   	
	    	
	        for (Camera camera : rentACamera)//looping of rentAcamera in camera
	        {
	        if (camera.camid == camId && "Available".equals(camera.status)) //checking the camid is available status
	        {
	        	double rentPerDay = camera.rentperday;
	        	
	        	
	        try
	        {
	        	if(user.getwalletamount() >= rentPerDay) //condition checking the walletamount is greater than or equals to the rent per day
	        	{
	            camera.setStatus("Rented");
	            camera.setRentedBy(user.getusername());
	            user.setwalletamount(user.getwalletamount()-rentPerDay);
	            return "YOUR TRANSACTION FOR CAMERA -"+" "+camera.brand+" "+camera.model+"WITH RENT INR."+" "+ camera.rentperday+"HAS SUCCESSFULLY COMPLETED";
	        	}
	        	else
	        	{
	        		throw new Exception( "ERROR:TRANSACTION FAILED DUE TO Insufficient WALLET BALANCE.PLEASE DEPOSIT THE AMOUNT TO YOUR WALLET.");// if the wallet amount is less than the wallet amount,this exception occurs
	        	}
	            
	        }
	        catch (Exception e)
	        {
	        	return e.getMessage();
	        }
	     }
	        else if (camera.camid == camId && "Rented".equals(camera.status)) 
	        {
 	            return "CAMERA IS ALREADY RENTED.";
	        }
	    }
	 	    return "CAMERA NOT FOUND OR UNAVAILABLE.";
	  }
	}