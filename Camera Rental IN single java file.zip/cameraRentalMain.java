package Camera;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;



 class userinfo 
{
	  private String username;
	    private String password;
	    private double walletamount;

	   //setters for userinfo 
	    public void setusername(String username) {
	        this.username = username;
	    }

	    public void setpassword(String password) {
	        this.password = password;
	    }

	    public void setwalletamount(double walletamount) {
	        this.walletamount = walletamount;
	    }
	    
	    //getters for userinfo

	    public String getusername() {
	        return username;
	    }

	    public String getpassword() {
	        return password;
	    }

	    public double getwalletamount() {
	        return walletamount;
	    }
	    
	    
	  //method for adding amount to the wallet
	    public void AddAmountToWallet()
	    {
	        Scanner scanner = new Scanner(System.in);//scanner to take the amount to be added as input
	        double currentbalance, newbalance;
	        
	        currentbalance = walletamount;
	        
	        System.out.println("\nCURRENT BALANCE:" + " " + currentbalance);//printing the current balance
	        System.out.println("DO YOU WANT TO DEPOSIT MORE AMOUNT TO YOUR WALLET");
	        System.out.println("1.YES"+"\n2.NO");
	        String choiceToAdd=scanner.next();//This scanner is used to get the user whether need to add money to wallet or not 
	        
	        
	        if("1".equals(choiceToAdd)) //this checks the input with the string "1" 
	        {
	        System.out.println("\n ENTER AMOUNT TO BE ADD TO THE WALLET:");
	        double amountToAdd = scanner.nextDouble();//this takes the input of amount which is need to add to the wallet
	        newbalance = currentbalance + amountToAdd;
	       setwalletamount(newbalance);// In this the wallet balance is updated with the new balance
	      

	    }
	        else
	        {
	        	System.out.println("NO AMOUNT ADDED. CURRENT BALANCE REMAINS:"+" "+currentbalance);//This step performs when the user not opted to add money to the wallet
	        }
	        	
	    }
}




class Camera {
	private static int initialCamId=0;
    int camid;
    String brand;
    String model;
    double rentperday;
    String status;
    String rentedBy;
    
    public Camera()
    {
    	this.camid=++initialCamId;
    }

    public void setStatus(String status)
    {
        this.status = status;
    }

    public String getstatus()
    {
        return status;
    }

    public void setRentedBy(String rentedBy) 
    {
        this.rentedBy = rentedBy;
    }

    public String getRentedBy() 
    {
        return rentedBy;
    
		
	}
}



     class CameraOperations 
      {
    	 private List<Camera> rentACamera = new ArrayList<>();//creating the list named rentACamera
 	    
 	    
         // this  used to add a new camera
 	    public String addCamera(Camera camera)
 	    {
 	    	 for (Camera existingCamera : rentACamera) 
 	    	 {
 	    	        if (existingCamera.camid == camera.camid)//checking with the camid entered with the existing camid
 	    	        {
 	    	            return "CAMERA ID ALREADY EXISTS. PLEASE CHOOSE A UNIQUE ID.";
 	    	        }
 	    	    }
 	            camera.setStatus("Available");
 	            rentACamera.add(camera);//camera is added to the list
 	            return "YOUR CAMERA HAS BEEN SUCCESSFULLY ADDED TO THE LIST.";
 	            
 	        }
 	  
 	    
 	    
 	    
         
 	    public String removeCamera(int camId) {
 	    	
 	        for (Camera camera : rentACamera) {
 	            if (camera.camid == camId) {
 	                rentACamera.remove(camera);
 	                return "CAMERA SUCCESSFULLY REMOVED FROM THE LIST.";
 	                
 	            }
 	        }
 	        return "CAMERA NOT FOUND.";
 	    }


 	    //method for listing the all cameras
 	    public void listCameras()
 	    {
 	        if (rentACamera.isEmpty())//checking the list is empty or not
 	        {
 	            System.out.println("NO CAMERAS AVAILABLE.");
 	        } 
 	        
 	        else
 	        {
 	        	
 	        	 System.out.println("\nLIST OF AVAILABLE CAMERAS:");
 	             System.out.println("================================================================================");
 	             System.out.println("CAMERA ID" + "       " + "BRAND" + "        " + "MODEL" + "         " + "RENT PER DAY" + "         " + "STATUS");
 	             System.out.println("================================================================================");
 	             for (Camera camera : rentACamera) {
 	                 System.out.println(camera.camid + "               " + camera.brand + "        " + camera.model + "         " + camera.rentperday + "             " + camera.status + "\n");
 	             }
 	        }
             System.out.println("================================================================================");

 	    } 

 	      
 	    
 	    public void viewMyCameras() 
 	    {
 	        listCameras();
 	    }

 	        

 	    public String rentCamera(int camId, userinfo user)
 	    {
 	    	
 	    	listCameras();//listing all the available cameras
 	    	Scanner sc=new Scanner(System.in);
 	    	System.out.println("ENTER CAMERA ID YOU WANT TO RENT:");
 	    	camId=sc.nextInt();  //taking input which camera need to take rent   	
 	    	
 	        for (Camera camera : rentACamera)//looping of rentAcamera in camera
 	        {
 	        if (camera.camid == camId && "Available".equals(camera.status)) //checking the camid is available status
 	        {
 	        	double rentPerDay = camera.rentperday;
 	        	
 	        	
 	        try
 	        {
 	        	if(user.getwalletamount() >= rentPerDay) //condition checking the walletamount is greater than or equals to the rent per day
 	        	{
 	            camera.setStatus("Rented");
 	            camera.setRentedBy(user.getusername());
 	            user.setwalletamount(user.getwalletamount()-rentPerDay);
 	            return "YOUR TRANSACTION FOR CAMERA -"+" "+camera.brand+" "+camera.model+"WITH RENT INR."+" "+ camera.rentperday+" "+"HAS SUCCESSFULLY COMPLETED";
 	        	}
 	        	else
 	        	{
 	        		throw new Exception( "ERROR:TRANSACTION FAILED DUE TO Insufficient WALLET BALANCE.PLEASE DEPOSIT THE AMOUNT TO YOUR WALLET.");// if the wallet amount is less than the wallet amount,this exception occurs
 	        	}
 	            
 	        }
 	        catch (Exception e)
 	        {
 	        	return e.getMessage();
 	        }
 	     }
 	        else if (camera.camid == camId && "Rented".equals(camera.status)) 
 	        {
  	            return "CAMERA IS ALREADY RENTED.";
 	        }
 	    }
 	 	    return "CAMERA NOT FOUND OR UNAVAILABLE.";
 	  }
 	}
  public class cameraRentalMain {
	
	  public static void main(String[] args)//main method
	    {
	        CameraOperations cameraOperations = new CameraOperations();   //creating object for class cameraOperations
	        userinfo user = new userinfo();     //creating object for class userinfo
	        user.setwalletamount(200);    //initializing the wallet amount
	     
	        System.out.println("+-------------------------------+");
	        System.out.println("| WELCOME TO CAMERA RENTAL APP  |");
	        System.out.println("+-------------------------------+");
	        System.out.println("PLEASE LOGIN TO CONTINUE-");
	        Scanner scanner = new Scanner(System.in);
	        System.out.print("ENTER USERNAME : ");     
	        String username = scanner.nextLine();    //taking username as input
	        System.out.print("ENTER PASSWORD : ");
	        String password = scanner.nextLine();    //taking password  as input
	        
	        if (authenticateUser(username, password)) 
	        {
	            System.out.println("LOGIN SUCCESSFUL. WELCOME, " + username + "!");
	            user.setusername(username);
	            
	            
	            Camera cam1=new Camera();     //initializing the some camera details for the  
	 	       cam1.brand="canon";
	 	       cam1.model="dslr200";
	 	       cam1.rentperday=200;	   
	 	       cameraOperations.addCamera(cam1);

	 	       
	 	       Camera cam2=new Camera();
	 	       cam2.brand="nixon";
	 	       cam2.model="dslr200";
	 	       cam2.rentperday=500;
	 	       cameraOperations.addCamera(cam2);

	 	       
	 	       Camera cam3=new Camera();
	 	       cam3.brand="nixon";
	 	       cam3.model="dsl8000";
	 	       cam3.rentperday=250;
	 	      cameraOperations.addCamera(cam3);

	 	       
	 	     Camera cam4=new Camera();
	 	       cam4.brand="sonym";
	 	       cam4.model="dslr80";
	 	       cam4.rentperday=2500;
	 	      cameraOperations.addCamera(cam4);
	 	      
	 	      
	 	     Camera cam5=new Camera();
	 	       cam5.brand="canon";
	 	       cam5.model="dsl8000";
	 	       cam5.rentperday=150;
	 	      cameraOperations.addCamera(cam5);
	 	      
	 	     Camera cam6=new Camera();
	 	       cam6.brand="canox";
	 	       cam6.model="ds20500";
	 	       cam6.rentperday=350;
	 	      cameraOperations.addCamera(cam6);
	        
	        int choice;

	        do {
	            System.out.println("\n MENU:");
	            System.out.println("1. MY CAMERA");
	            System.out.println("2. RENT A CAMERA");
	            System.out.println("3. VIEW ALL CAMERAS");
	            System.out.println("4. MY WALLET");
	            System.out.println("5. EXIT");
	            System.out.print("ENTER YOUR CHOICE: ");
	            choice = scanner.nextInt();

	            switch (choice) {                                       //switch case for the main menu
	                case 1:
	                    handleMyCamera(cameraOperations);
	                    
	                    break;
	                case 2:
	                    String rentResult = cameraOperations.rentCamera(choice, user);
	                    System.out.println(rentResult);
	                    break;
	                case 3:
	                    cameraOperations.listCameras();
	                    break;
	                case 4:
	                    user.AddAmountToWallet();
	                    System.out.println("WALLET BALANCE UPDATED."+"CURRENT BALANCE - INR."+user.getwalletamount());
	                    break;
	                case 5:
	                    System.out.println("EXITING THE PROGRAM. GOODBYE!");
	                    scanner.close();
	                    break;
	                default:
	                    System.out.println("INVALID CHOICE.PLEASE ENTER A VALID OPTION.");
	            }
	        } while (choice != 5);
	    }
	        else {
	        	System.out.println("USER NOT FOUND");
	        }
	    }
	        
	    private static boolean authenticateUser(String enteredUsername, String enteredPassword) {
	    	 String username = "bhargav";
	         String password = "password";
	         return enteredUsername.equals(username) && enteredPassword.equals(password);
		}

		private static void handleMyCamera(CameraOperations cameraOperations) {
	        Scanner scanner = new Scanner(System.in);
	        int myCameraChoice;

	        do {
	        	  System.out.println("\n MY CAMERA MENU:");
	              System.out.println("1. ADD CAMERA");
	              System.out.println("2. REMOVE CAMERA");
	              System.out.println("3. VIEW MY CAMERAS");
	              System.out.println("4. GO TO PREVIOUS MENU");
	              System.out.print("ENTER YOUR CHOICE: ");
	            myCameraChoice = scanner.nextInt();

	            switch (myCameraChoice) {
	                case 1:
	                    handleAddCamera(cameraOperations);
                       cameraOperations.listCameras();
	                    break;
	                case 2:
	                	cameraOperations.listCameras();
	              	   System.out.print("ENTER CAMERA ID TO REMOVE: ");
	                	   int camId = scanner.nextInt();
	                	   String removeResult = cameraOperations.removeCamera(camId);
	                       System.out.println(removeResult);
		                	cameraOperations.listCameras();

	                    break;
	                case 3:
	                	
	                    cameraOperations.viewMyCameras();
	                    break;
	                case 4:
	                    System.out.println("GOING TO THE PREVIOUS MENU.");
	                    break;
	                default:
	                    System.out.println("INVALID CHOICE.PLEASE ENTER A VALID OPTION.");
	            }
	        } while (myCameraChoice != 4);
	    }

	    private static void handleAddCamera(CameraOperations cameraOperations) {             //method to add a new camera details
	       
	    	Scanner scanner = new Scanner(System.in);
	    	Camera newCamera = new Camera();     
	        System.out.print("ENTER BRAND: ");
	        newCamera.brand = scanner.next();
	        System.out.print("ENTER MODEL: ");
	        newCamera.model = scanner.next();
	        System.out.print("ENTER RENT PER DAY: ");
	        newCamera.rentperday = scanner.nextFloat();

	        String addResult = cameraOperations.addCamera(newCamera);
	        System.out.println(addResult);
	    }
}